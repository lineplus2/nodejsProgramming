const passport = require('passport');
const FacebookStrategy = require('passport-facebook').Strategy; // 이 부분 추가

const User = require('../models/user');

module.exports = () => {
  passport.use(new FacebookStrategy({
    clientID: process.env.FACEBOOK_ID,
    clientSecret: process.env.FACEBOOK_SECRET,
    callbackURL: '/auth/facebook/callback',
  }, async (accessToken, refreshToken, profile, done) => {
    console.log('facebook profile info', profile);
    const _profile = profile._json;

    try {
      const exUser = await User.findOne({
        where: { snsId: profile.id, provider: 'facebook' },
      });
      if (exUser) {
        done(null, exUser);
      } else {
        const newUser = await User.create({
          email: _profile.email,
          nick: _profile.displayName,
          snsId: _profile.id,
          provider: 'facebook',
        });
        done(null, newUser);
      }
    } catch (error) {
      console.error(error);
      done(error);
    }
  }));
};