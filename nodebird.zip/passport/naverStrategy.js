const passport = require('passport');
const NaverStrategy = require('passport-naver').Strategy;

const User = require('../models/user');

module.exports = () => {
  passport.use(new NaverStrategy({
    clientID: process.env.NAVER_ID,
    clientSecret: process.env.NAVER_SECRET,
    callbackURL: '/auth/naver/callback',
  }, async (accessToken, refreshToken, profile, done) => {
    const _profile = profile._json;
    console.log('naver profile info');
    console.info(_profile);
    try {
      const exUser = await User.findOne({
        where: { snsId: profile.id, provider: 'naver' },
      });
      if (exUser) {
        done(null, exUser);
      } else {
        const newUser = await User.create({
          email: _profile.email,
          nick: _profile.nickname,
          snsId: _profile.id,
          provider: 'naver',
        });
        done(null, newUser);
      }
    } catch (error) { 
      console.error(error);
      done(error);
    }
  }));
};
